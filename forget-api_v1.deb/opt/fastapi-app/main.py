from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel, EmailStr
from pymongo import MongoClient
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import random
import bcrypt
from datetime import datetime

app = FastAPI()

# MongoDB connection settings
MONGO_URI = "mongodb://localhost:27017/"
DATABASE_NAME = "Deepanshu_db"
client = MongoClient(MONGO_URI)
db = client[DATABASE_NAME]

# Pydantic models
class User(BaseModel):
    username: str
    fullname: str
    email: EmailStr
    password: str

class ResetRequest(BaseModel):
    email: EmailStr

class OTPVerification(BaseModel):
    email: EmailStr
    otp: str
    new_password: str
    confirm_password: str

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

# Centralized SMTP configuration
smtp_settings = {
    "sender": "Greetings@diagonal.ai",
    "subject": "OTP for Verification",
    "smtp_server": "smtp.office365.com",
    "smtp_port": 587,
    "password": "tlvbxpgxstpxtjcy",  # Replace with your SMTP password or use environment variables for security
}

# Utility function to send an HTML email
def mail_sending(otp: str, body: str, email_receive: str, smtp_config: dict) -> None:
    """
    Sends an HTML email with an OTP to the specified email address.

    Parameters:
    - otp (str): The OTP to include in the email.
    - body (str): The message body.
    - email_receive (str): Recipient's email address.
    - smtp_config (dict): SMTP configuration settings.
    """
    html_body = f"""
    <html>
        <body style="font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px;">
            <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 10px; overflow: hidden; box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);">
                <div style="background-color: #4CAF50; color: #ffffff; padding: 20px; text-align: center;">
                    <h2 style="margin: 0;">Aryabhat</h2>
                    <p style="margin: 0;">Your AI for Smarter Solutions</p>
                </div>
                <div style="padding: 20px;">
                    <h3>Hello,</h3>
                    <p>{body}</p>
                    <p style="font-size: 24px; font-weight: bold; color: #4CAF50;">{otp}</p>
                    <p>Please use this OTP to reset your password. It is valid for 2 minutes.</p>
                    <p>If you did not request a password reset, please ignore this email.</p>
                    <br>
                    <p>Best regards,<br>The Aryabhat Team</p>
                </div>
                <div style="background-color: #f1f1f1; padding: 10px; text-align: center; font-size: 12px; color: #888;">
                    <p>© 2024 Aryabhat, All rights reserved.</p>
                </div>
            </div>
        </body>
    </html>
    """
    
    try:
        # Create a MIME multipart message for both HTML and plain text
        msg = MIMEMultipart("alternative")
        msg["From"] = smtp_config["sender"]
        msg["To"] = email_receive
        msg["Subject"] = smtp_config["subject"]

        plain_body = f"{body} {otp}"
        msg.attach(MIMEText(plain_body, "plain"))
        msg.attach(MIMEText(html_body, "html"))

        # Establish SMTP connection
        with smtplib.SMTP(smtp_config["smtp_server"], smtp_config["smtp_port"]) as server:
            server.starttls()
            server.login(smtp_config["sender"], smtp_config["password"])
            server.sendmail(smtp_config["sender"], email_receive, msg.as_string())

        print("HTML Email sent successfully")

    except Exception as e:
        print(f"Error sending mail: {e}")

# Utility function to hash a password
def hash_password(password: str) -> str:
    """
    Hashes the password using bcrypt.

    Parameters:
    - password (str): Plain text password to hash.

    Returns:
    - str: Hashed password as a string.
    """
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed_password.decode('utf-8')

# Utility function to verify hashed password
def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Verifies a plain password against a hashed password.

    Parameters:
    - plain_password (str): Plain password to verify.
    - hashed_password (str): Hashed password to compare.

    Returns:
    - bool: True if passwords match, False otherwise.
    """
    return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))

# Ensure TTL index on 'otp_storage' collection at app startup
@app.on_event("startup")
def create_ttl_index():
    """
    Creates a TTL (Time to Live) index on the 'created_at' field in the 'otp_storage' collection.
    Documents in this collection will expire 5 minutes after creation.
    """
    db.otp_storage.create_index("created_at", expireAfterSeconds=300)

# Endpoint to register a new user
@app.post(
    "/register/",
    summary="Register a New User",
    description="Creates a new user in the database with the provided information. Password is securely hashed before storage.",
    response_description="A message confirming the user's successful registration."
)
async def register(user: User):
    """
    Registers a new user with a unique email address.

    - **Parameters**:
        - `user` (User): A Pydantic model containing user registration information including username, full name, email, and password.
    - **Response**:
        - **200 OK**: Success message confirming registration.
        - **400 Bad Request**: If user with email already exists.
    """
    hashed_password = hash_password(user.password)
    user_data = {
        "username": user.username,
        "fullname": user.fullname,
        "email": user.email,
        "password": hashed_password
    }
    db.users2.insert_one(user_data)
    return {"message": "User registered successfully."}

# Endpoint to request a password reset OTP
@app.post(
    "/reset-password/",
    summary="Request Password Reset OTP",
    description="Sends an OTP to the user’s registered email for password reset verification. The OTP is valid for 2 minutes.",
    response_description="A message indicating OTP was sent to the user's email."
)
async def reset_password(reset_request: ResetRequest):
    """
    Sends an OTP to the specified email for password reset purposes.

    - **Parameters**:
        - `reset_request` (ResetRequest): A model containing the email address of the user requesting password reset.
    - **Response**:
        - **200 OK**: Message indicating OTP was successfully sent.
        - **404 Not Found**: If the email is not registered.
    """
    user = db.users2.find_one({"email": reset_request.email})
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Email not found")

    otp = str(random.randint(100000, 999999))
    otp_data = {
        "email": reset_request.email,
        "otp": otp,
        "created_at": datetime.utcnow()
    }
    db.otp_storage.insert_one(otp_data)
    mail_sending(otp, "Your OTP for password reset is: ", reset_request.email, smtp_settings)
    return {"message": "OTP sent to your email."}

# Endpoint to verify OTP and reset password
@app.post(
    "/verify-otp/",
    summary="Verify OTP and Reset Password",
    description="Verifies the OTP sent to the user’s email and, upon successful verification, allows the user to reset their password.",
    response_description="A message indicating successful password reset."
)
async def verify_otp(otp_verification: OTPVerification):
    """
    Verifies the OTP for password reset and updates the password.

    - **Parameters**:
        - `otp_verification` (OTPVerification): A model containing the user's email, OTP, new password, and confirmed password.
    - **Response**:
        - **200 OK**: Message indicating password reset was successful.
        - **400 Bad Request**: If OTP is invalid or passwords do not match.
    """
    otp_record = db.otp_storage.find_one({"email": otp_verification.email, "otp": otp_verification.otp})
    if not otp_record:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid OTP or email.")

    if otp_verification.new_password != otp_verification.confirm_password:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Passwords do not match.")

    hashed_password = hash_password(otp_verification.new_password)
    db.users2.update_one({"email": otp_verification.email}, {"$set": {"password": hashed_password}})
    db.otp_storage.delete_one({"_id": otp_record["_id"]})
    return {"message": "Password reset successfully."}

# Endpoint for user login
@app.post(
    "/login/",
    summary="User Login",
    description="Authenticates a user by verifying email and password. Returns a success message upon successful login.",
    response_description="A message indicating successful login."
)
async def login(login_request: LoginRequest):
    """
    Authenticates a user with email and password.

    - **Parameters**:
        - `login_request` (LoginRequest): A model containing the user's email and password.
    - **Response**:
        - **200 OK**: Message indicating login was successful.
        - **404 Not Found**: If the email is not registered.
        - **400 Bad Request**: If the password is incorrect.
    """
    user = db.users2.find_one({"email": login_request.email})
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Email not registered.")

    hashed_password = user["password"]
    if not verify_password(login_request.password, hashed_password):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Incorrect password.")
    
    return {"message": "Login successful."}
