from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    mongodb_url: str = "mongodb://localhost:27017"
    database_name: str = "Deepanshu_db"
    smtp_sender: str = "Greetings@diagonal.ai"
    smtp_password: str = "tlvbxpgxstpxtjcy"
    smtp_server: str = "smtp.office365.com"
    smtp_port: int = 587

    class Config:
        env_file = ".env"

settings = Settings()
